using System;
using System.Collections.Generic;
using System.IO;

class Solution {
    static void Main(String[] args) {
        int i = 4;
        double d = 4.0;
        string s = "HackerRank ";


    
        int inputI = int.Parse(Console.ReadLine());
        double inputD = double.Parse(Console.ReadLine());
        string inputS = Console.ReadLine();

    
        Console.WriteLine(i + inputI);
        Console.WriteLine((d + inputD).ToString("0.0"));
        Console.WriteLine(s + inputS);
    

        
        // Declare second integer, double, and String variables.
        
        // Read and save an integer, double, and String to your variables.
        
        // Print the sum of both integer variables on a new line.
        
        // Print the sum of the double variables on a new line.
        
        // Concatenate and print the String variables on a new line
        // The 's' variable above should be printed first.

    }
}